# Change Log

## [0.0.2] 2024-12-15
### Changes

- Added Backend
- Added React UI (Mantis Design)

## [0.0.1] 2024-11-11
### Changes

- REPO Created
- Specs Added (RM)
